# POSTA Auto

Aplicación web progresiva mobile-first para organizar vehículos familiares. Funciona sin compilación y guarda los datos en el navegador mediante `localStorage`.

## Publicar en GitHub Pages

1. Descomprimí `posta-auto-github.zip`.
2. Subí **todos los archivos y la carpeta `icons`** a tu repositorio. `index.html` debe quedar en la raíz.
3. En GitHub abrí **Settings → Pages**.
4. En **Build and deployment**, elegí **Deploy from a branch**.
5. Seleccioná la rama **main** y la carpeta **/(root)**. Guardá.
6. Abrí el enlace que GitHub genere.

## Instalar en el celular

- En Android/Chrome: abrí el enlace, menú ⋮ y elegí **Agregar a pantalla principal** o **Instalar app**.
- En iPhone/Safari: abrí el enlace, tocá **Compartir** y luego **Agregar a inicio**.

## Límites de esta versión

- Los datos quedan guardados solo en el navegador y dispositivo donde se usan.
- No hay sincronización real entre diferentes celulares.
- El chat, las invitaciones y las notificaciones son locales.
- La ubicación usa el permiso del navegador y conserva la última ubicación registrada; no realiza seguimiento oculto ni GPS en segundo plano.
- Borrar los datos del navegador puede borrar la información de la app.
- Para una versión comercial multiusuario se necesita un backend seguro, autenticación y base de datos.
